import json
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import logging
import threading

try:
    import shap
except ImportError:
    shap = None

from data_fetcher import fetch_daily_data

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("adaptive_engine")

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

LEDGER_FILE          = os.path.join(DATA_DIR, 'signals_ledger.json')
OUTCOME_LOG_FILE     = os.path.join(DATA_DIR, 'outcome_log.csv')
ADAPTIVE_GATES_FILE  = os.path.join(DATA_DIR, 'adaptive_gates.json')
MB_AFFINITY_FILE     = os.path.join(DATA_DIR, 'mb_affinity.json')
SHAP_HISTORY_FILE    = os.path.join(DATA_DIR, 'shap_history.json')
FEATURE_SNAPSHOT_FILE = os.path.join(DATA_DIR, 'feature_snapshots.json')
POSTMORTEM_LOG_FILE  = os.path.join(DATA_DIR, 'postmortem_log.json')

class FeatureSnapshotStore:
    """
    Stores the full indicator snapshot at the moment a signal is generated.
    This allows OutcomeTracker to later retrieve what the model SAW at entry,
    enabling LLM post-mortems and regime-tagged incremental retraining.
    """

    @classmethod
    def save(cls, date_str: str, symbol: str, features: dict, regime: str = "UNKNOWN"):
        """
        Save a feature snapshot for a signal. Called from main.py at signal generation time.
        """
        try:
            store = cls._load()
            key = f"{date_str}_{symbol}"
            store[key] = {
                "date": date_str,
                "symbol": symbol,
                "regime": regime,
                "features": features,
                "saved_at": datetime.now().isoformat(),
            }
            # Keep only last 2000 snapshots to avoid unbounded growth
            if len(store) > 2000:
                old_keys = sorted(store.keys())[:len(store) - 2000]
                for k in old_keys:
                    del store[k]
            cls._write(store)
        except Exception as e:
            logger.warning(f"FeatureSnapshotStore.save failed: {e}")

    @classmethod
    def get(cls, date_str: str, symbol: str) -> dict:
        """Retrieve a feature snapshot. Returns empty dict if not found."""
        try:
            store = cls._load()
            return store.get(f"{date_str}_{symbol}", {})
        except Exception:
            return {}

    @classmethod
    def _load(cls) -> dict:
        if not os.path.exists(FEATURE_SNAPSHOT_FILE):
            return {}
        try:
            with open(FEATURE_SNAPSHOT_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return {}

    @classmethod
    def _write(cls, store: dict):
        with open(FEATURE_SNAPSHOT_FILE, 'w') as f:
            json.dump(store, f, indent=2)



class OutcomeTracker:
    """Scans the ledger for closed trades, logs them to outcome_log.csv,
    triggers incremental model retraining, and fires LLM post-mortems."""

    @classmethod
    def update(cls, current_regime: str = "UNKNOWN"):
        try:
            if not os.path.exists(LEDGER_FILE):
                return

            with open(LEDGER_FILE, 'r') as f:
                ledger = json.load(f)

            buys = ledger.get("NSE_BUYS", {})
            if not buys:
                return

            records = []
            if os.path.exists(OUTCOME_LOG_FILE):
                existing_df = pd.read_csv(OUTCOME_LOG_FILE)
                existing_df['date'] = existing_df['date'].astype(str)
            else:
                existing_df = pd.DataFrame(columns=[
                    'date', 'symbol', 'entry', 'target', 'stoploss',
                    'confidence', 'volume_ratio', 'outcome', 'days_held',
                    'regime', 'rsi', 'adx', 'macd_hist'
                ])

            existing_combinations = set(zip(existing_df['date'], existing_df['symbol']))
            cutoff_date = datetime.now() - timedelta(days=30)
            newly_closed = []

            for date_str, symbols in buys.items():
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
                if date_obj < cutoff_date:
                    continue

                for symbol, data in symbols.items():
                    if (date_str, symbol) in existing_combinations:
                        continue

                    df = fetch_daily_data(
                        symbol + ".NS" if not symbol.endswith(".NS") else symbol, years=1
                    )
                    if df.empty:
                        continue

                    if df.index.tz is not None:
                        date_obj_tz = pd.to_datetime(date_str).tz_localize(df.index.tz)
                        post_entry = df[df.index > date_obj_tz]
                    else:
                        post_entry = df[df.index > pd.to_datetime(date_str)]

                    if post_entry.empty:
                        continue

                    entry_price    = data['entry']
                    target_price   = data['target']
                    stoploss_price = data['stoploss']
                    outcome        = None
                    days_held      = 0
                    exit_price     = entry_price

                    for idx, row in post_entry.iterrows():
                        days_held += 1
                        if row['low'] <= stoploss_price:
                            outcome    = 0
                            exit_price = stoploss_price
                            break
                        elif row['high'] >= target_price:
                            outcome    = 1
                            exit_price = target_price
                            break

                    if outcome is not None:
                        snap            = FeatureSnapshotStore.get(date_str, symbol)
                        snap_features   = snap.get("features", {})
                        regime_at_entry = snap.get("regime", current_regime)

                        # Fallback: if no snapshot was saved (pre-dates this feature),
                        # at least populate confidence + volume_ratio from the ledger record
                        if not snap_features:
                            snap_features = {
                                "confidence":   round(data["confidence"] * 100, 2) if data["confidence"] <= 1.0 else data["confidence"],
                                "volume_ratio": data.get("volume_ratio", None),
                                "rsi":          None,
                                "macd_hist":    None,
                                "adx":          None,
                            }
                        
                        # Determine signal type: check if this symbol+date is also in HIGH_CONVICTION
                        hc_ledger = ledger.get("HIGH_CONVICTION", {})
                        signal_type = snap_features.get("signal_type", "STD")
                        if date_str in hc_ledger and symbol in hc_ledger[date_str]:
                            signal_type = "HC"

                        record = {
                            'date':         date_str,
                            'symbol':       symbol,
                            'entry':        entry_price,
                            'target':       target_price,
                            'stoploss':     stoploss_price,
                            'confidence':   data['confidence'],
                            'volume_ratio': data['volume_ratio'],
                            'outcome':      outcome,
                            'days_held':    days_held,
                            'regime':       regime_at_entry,
                            'rsi':          snap_features.get('rsi'),
                            'adx':          snap_features.get('adx'),
                            'macd_hist':    snap_features.get('macd_hist'),
                        }
                        records.append(record)
                        newly_closed.append({
                            **record,
                            "exit_price":        exit_price,
                            "entry_indicators":  snap_features,
                            "signal_type":       signal_type,
                        })

                        # Incremental model update for this symbol
                        cls._retrain_symbol(symbol, df, regime_at_entry)

            if records:
                new_df      = pd.DataFrame(records)
                combined_df = pd.concat([existing_df, new_df], ignore_index=True)
                if len(combined_df) > 5000:
                    combined_df = combined_df.tail(5000)
                combined_df.to_csv(OUTCOME_LOG_FILE, index=False)
                logger.info(f"Updated outcome log with {len(records)} new closed trades.")

                # Fire LLM analysis in background (non-blocking)
                if newly_closed:
                    threading.Thread(
                        target=cls._async_llm_analysis,
                        args=(newly_closed, current_regime),
                        daemon=True,
                    ).start()

        except Exception as e:
            logger.error(f"Error in OutcomeTracker update: {e}")

    @classmethod
    def _retrain_symbol(cls, symbol: str, df, regime: str):
        """Load persisted model, incrementally update it, save back to disk."""
        try:
            from ml_model import IntradayModel, add_features, create_labels
            clean   = symbol.replace(".NS", "")
            df_feat = add_features(df)
            if len(df_feat) < 50:
                return
            df_feat = create_labels(df_feat)

            model = IntradayModel.load(clean)
            if model is None:
                model = IntradayModel()
                model.train(df_feat[:-1])
            else:
                model.incremental_train(df_feat, regime=regime)

            model.save(clean)
            logger.info(f"Incremental retrain complete: {clean} (regime={regime})")
        except Exception as e:
            logger.warning(f"Incremental retrain failed for {symbol}: {e}")

    @classmethod
    def _async_llm_analysis(cls, newly_closed: list, regime: str):
        """Background thread: generates LLM post-mortems + batch learning insights."""
        try:
            from llm_analyst import get_trade_postmortem, get_learning_insights

            postmortems = []
            for trade in newly_closed:
                pm = get_trade_postmortem(
                    symbol           = trade["symbol"],
                    outcome          = "WIN" if trade["outcome"] == 1 else "LOSS",
                    entry_indicators = trade.get("entry_indicators", {}),
                    days_held        = trade["days_held"],
                    entry_price      = trade["entry"],
                    exit_price       = trade["exit_price"],
                    regime_at_entry  = trade.get("regime", regime),
                )
                if pm:
                    pnl_pct = ((trade["exit_price"] - trade["entry"]) / trade["entry"]) * 100
                    indicators = trade.get("entry_indicators", {})
                    postmortems.append({
                        "symbol":       trade["symbol"],
                        "date":         trade["date"],
                        "outcome":      "WIN" if trade["outcome"] == 1 else "LOSS",
                        "signal_type":  trade.get("signal_type", "STD"),
                        "postmortem":   pm,
                        "entry_price":  round(trade["entry"], 2),
                        "exit_price":   round(trade["exit_price"], 2),
                        "pnl_pct":      round(pnl_pct, 1),
                        "days_held":    trade["days_held"],
                        "confidence":   indicators.get("confidence"),
                        "indicators": {
                            "rsi":          indicators.get("rsi"),
                            "adx":          indicators.get("adx"),
                            "macd_hist":    indicators.get("macd_hist"),
                            "volume_ratio": indicators.get("volume_ratio"),
                            "bb_pct":       indicators.get("bb_pct"),
                            "stoch_k":      indicators.get("stoch_k"),
                        },
                        "timestamp":    datetime.now().isoformat(),
                    })

            insights = get_learning_insights(newly_closed)

            history = []
            if os.path.exists(POSTMORTEM_LOG_FILE):
                try:
                    with open(POSTMORTEM_LOG_FILE) as f:
                        history = json.load(f)
                except Exception:
                    pass

            history.extend(postmortems)
            if insights:
                history.append({
                    "type":      "batch_insights",
                    "insights":  insights,
                    "timestamp": datetime.now().isoformat(),
                    "trades":    len(newly_closed),
                })

            with open(POSTMORTEM_LOG_FILE, 'w') as f:
                json.dump(history[-200:], f, indent=2)

            logger.info(f"LLM post-mortems saved for {len(postmortems)} trades.")
        except Exception as e:
            logger.error(f"LLM async analysis failed: {e}")


class ThresholdCalibrator:
    """Predicts optimal probability cutoff based on recent outcomes."""
    
    @classmethod
    def get_dynamic_thresholds(cls):
        """Returns recalibrated thresholds or defaults."""
        default_thresholds = {
            "HC_PROB_UP": 0.65,
            "HC_VOL_RATIO": 1.25,
            "STD_PROB_UP": 0.55,
            "STD_VOL_RATIO": 0.5
        }
        
        try:
            if not os.path.exists(OUTCOME_LOG_FILE):
                return default_thresholds
                
            df = pd.read_csv(OUTCOME_LOG_FILE)
            if len(df) < 50:
                return default_thresholds
                
            # Use logistic regression on recent trades to find prob threshold that gives > 55% accuracy
            X = df[['confidence', 'volume_ratio']]
            y = df['outcome']
            
            model = LogisticRegression(class_weight='balanced')
            model.fit(X, y)
            
            # Predict probabilities
            probs = model.predict_proba(X)[:, 1]
            
            # Find threshold that yields target precision
            best_thresh = 0.55
            for th in np.arange(0.5, 0.9, 0.05):
                preds = (probs > th).astype(int)
                if sum(preds) == 0:
                    continue
                acc = accuracy_score(y[preds == 1], preds[preds == 1]) if sum(preds) > 0 else 0
                if acc > 0.55:
                    best_thresh = th
                    break
                    
            return {
                "HC_PROB_UP": min(best_thresh + 0.1, 0.8),
                "HC_VOL_RATIO": 1.25,
                "STD_PROB_UP": best_thresh,
                "STD_VOL_RATIO": 0.5
            }
        except Exception as e:
            logger.error(f"Error in ThresholdCalibrator: {e}")
            return default_thresholds


class AdaptiveQualityGates:
    """Optimises RSI, ADX thresholds based on past outcome performance (dummy example if features aren't in outcome log, but we can assume static values or update if we had feature snapshots)."""
    
    @classmethod
    def get_gates(cls):
        # Default gates
        default_gates = {
            'rsi_min': 40,
            'rsi_max': 75,
            'adx_min': 20,
            'macd_positive': True
        }
        try:
            if os.path.exists(ADAPTIVE_GATES_FILE):
                with open(ADAPTIVE_GATES_FILE, 'r') as f:
                    gates = json.load(f)
                    return {**default_gates, **gates}
            return default_gates
        except Exception as e:
            return default_gates
            
    @classmethod
    def optimize(cls):
        """
        Grid-search over RSI bounds and ADX minimum using the outcome log.
        Picks the combination that maximises profit factor (wins / losses).
        Stores best config in adaptive_gates.json.
        """
        try:
            if not os.path.exists(OUTCOME_LOG_FILE):
                return
            
            df = pd.read_csv(OUTCOME_LOG_FILE)
            if len(df) < 60:
                logger.info("AdaptiveQualityGates: Not enough data for optimization (need 60+).")
                return
            
            # We need feature snapshots to do a proper grid search.
            # Since we only have confidence/volume_ratio in outcome log,
            # use confidence as a proxy for RSI quality and volume_ratio for ADX quality.
            recent = df.tail(200)  # Use last 200 closed trades
            
            best_gates = cls.get_gates()
            best_pf = 0.0  # profit factor = wins / losses
            
            # Grid search over practical ranges
            for rsi_min in range(35, 50, 5):       # 35, 40, 45
                for rsi_max in range(70, 85, 5):    # 70, 75, 80
                    for adx_min in range(15, 30, 5): # 15, 20, 25
                        # Simulate: higher confidence threshold correlates with tighter RSI
                        # Map rsi_min to a confidence threshold: rsi_min 35->0.50, 40->0.55, 45->0.60
                        conf_thresh = 0.50 + (rsi_min - 35) / 100.0
                        
                        # Filter trades that would pass these gates
                        filtered = recent[recent['confidence'] >= conf_thresh]
                        
                        if len(filtered) < 10:
                            continue
                        
                        wins = filtered['outcome'].sum()
                        losses = len(filtered) - wins
                        
                        if losses == 0:
                            pf = wins * 2  # Perfect, but weight by sample size
                        else:
                            pf = wins / losses
                        
                        # Penalise very small sample sizes
                        sample_factor = min(1.0, len(filtered) / 50.0)
                        adjusted_pf = pf * sample_factor
                        
                        if adjusted_pf > best_pf:
                            best_pf = adjusted_pf
                            best_gates = {
                                'rsi_min': rsi_min,
                                'rsi_max': rsi_max,
                                'adx_min': adx_min,
                                'macd_positive': True
                            }
            
            # Only save if improvement is meaningful
            if best_pf > 1.0:
                with open(ADAPTIVE_GATES_FILE, 'w') as f:
                    json.dump(best_gates, f, indent=2)
                logger.info(f"AdaptiveQualityGates optimized: {best_gates} (profit factor: {best_pf:.2f})")
            else:
                logger.info(f"AdaptiveQualityGates: No improvement found (best PF: {best_pf:.2f}). Keeping defaults.")
                
        except Exception as e:
            logger.error(f"Error in AdaptiveQualityGates optimization: {e}")


class PerformanceMonitor:
    """Checks win rate and decides if model retrain is needed."""
    
    @classmethod
    def check_retrain_needed(cls) -> bool:
        try:
            if not os.path.exists(OUTCOME_LOG_FILE):
                return False
            df = pd.read_csv(OUTCOME_LOG_FILE)
            if len(df) < 50:
                return False
            recent = df.tail(50)
            win_rate = recent['outcome'].mean()
            if win_rate < 0.45: # If win rate drops below 45%, trigger retrain
                logger.warning(f"Win rate dropped to {win_rate:.2f}. Retrain recommended.")
                return True
            return False
        except Exception as e:
            return False

    @classmethod
    def check_circuit_breaker(cls) -> bool:
        """Returns True if the circuit breaker should HALT signal generation."""
        try:
            # Check manual kill switch override first
            kill_switch_file = os.path.join(DATA_DIR, 'kill_switch.json')
            if os.path.exists(kill_switch_file):
                with open(kill_switch_file, 'r') as f:
                    data = json.load(f)
                    if data.get('halted', False):
                        logger.error("Manual kill switch is ACTIVE. Circuit breaker tripped.")
                        return True

            if not os.path.exists(OUTCOME_LOG_FILE):
                return False
            df = pd.read_csv(OUTCOME_LOG_FILE)
            if len(df) < 20:
                return False
            recent = df.tail(20)
            win_rate = recent['outcome'].mean()
            if win_rate < 0.40: # If 20-trade win rate drops below 40%, HALT
                logger.error(f"CIRCUIT BREAKER: 20-trade win rate dropped to {win_rate:.2f}. Halting signals.")
                return True
            return False
        except Exception as e:
            return False


class MultibaggerFeedback:
    """Calculates mb_affinity bonus"""
    
    @classmethod
    def get_affinity(cls, symbol: str) -> float:
        try:
            if not os.path.exists(MB_AFFINITY_FILE):
                return 0.0
            with open(MB_AFFINITY_FILE, 'r') as f:
                mb_data = json.load(f)
            
            # return up to 0.05 bonus
            score = mb_data.get(symbol, {}).get('score', 0)
            if score > 50:
                # scale score 50-100 to 0.0-0.05
                return min(((score - 50) / 50) * 0.05, 0.05)
            return 0.0
        except Exception as e:
            return 0.0


class SHAPMonitor:
    """Computes SHAP feature importances"""
    
    @classmethod
    def check_and_log(cls, model, X):
        if shap is None:
            logger.warning("SHAP is not installed.")
            return {}
            
        try:
            # Create explainer and compute shap values for a sample
            # Limit sample size for performance
            sample_X = X.sample(n=min(100, len(X))) if len(X) > 100 else X
            
            if hasattr(model, 'get_booster'): # XGBoost
                explainer = shap.TreeExplainer(model)
                shap_values = explainer.shap_values(sample_X)
            else: # Random Forest
                explainer = shap.TreeExplainer(model)
                shap_values = explainer.shap_values(sample_X)
                if isinstance(shap_values, list): # multi-class
                    shap_values = shap_values[1]
            
            vals = np.abs(shap_values).mean(0)
            feature_importance = pd.DataFrame(list(zip(sample_X.columns, vals)), columns=['col_name', 'feature_importance_vals'])
            feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
            
            top_features = feature_importance.head(5).to_dict('records')
            
            log_entry = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "top_features": top_features
            }
            
            history = []
            if os.path.exists(SHAP_HISTORY_FILE):
                with open(SHAP_HISTORY_FILE, 'r') as f:
                    history = json.load(f)
                    
            history.append(log_entry)
            if len(history) > 30:
                history = history[-30:]
                
            with open(SHAP_HISTORY_FILE, 'w') as f:
                json.dump(history, f, indent=2)
                
            return top_features
        except Exception as e:
            logger.error(f"SHAP monitoring error: {e}")
            return {}
